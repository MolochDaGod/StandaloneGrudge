# 🎮 WARLORD CRAFTING SUITE - GAME MASTER DESIGN DOCUMENT
**Role:** Authoritative Design for All Harvesting, Loot, and Rewards  
**Version:** 1.0  
**Date:** 2026-01-25

---

## 📜 TABLE OF CONTENTS
1. [Design Philosophy](#design-philosophy)
2. [Resource Gathering Systems](#resource-gathering-systems)
3. [Mob Drop Tables](#mob-drop-tables)
4. [Boss Loot Systems](#boss-loot-systems)
5. [Daily Mission Rewards](#daily-mission-rewards)
6. [Economy Balance](#economy-balance)
7. [Profession Bonuses](#profession-bonuses)

---

## 🎯 DESIGN PHILOSOPHY

### Core Principles
1. **Meaningful Progression**: Every tier should feel rewarding and necessary
2. **Multiple Paths**: Players can progress through gathering, combat, or missions
3. **Profession Identity**: Each profession has unique gathering methods and bonuses
4. **Rarity Excitement**: Rare nodes and drops create memorable moments
5. **Balanced Economy**: Resources flow at rates that support crafting without inflation

### Rarity System (Universal)
```
COMMON      - 70% spawn  - 1.0x rewards - Gray
UNCOMMON    - 20% spawn  - 1.25x rewards - Green  
RARE        - 8% spawn   - 1.5x rewards - Blue
EPIC        - 1.5% spawn - 2.0x rewards - Purple
LEGENDARY   - 0.5% spawn - 3.0x rewards - Gold
```

### Tier Progression (T0-T8)
```
T0 (Starter)    - Level 1   - 100% success - Hand-gathered basics
T1 (Basic)      - Level 1-9  - 100% success - First profession tools
T2 (Improved)   - Level 10-19 - 98% success - Quality materials
T3 (Quality)    - Level 20-34 - 95% success - Advanced crafting
T4 (Advanced)   - Level 35-49 - 90% success - Rare materials
T5 (Superior)   - Level 50-64 - 85% success - Elite gear
T6 (Masterwork) - Level 65-79 - 80% success - Legendary items
T7 (Legendary)  - Level 80-94 - 75% success - Mythic power
T8 (Divine)     - Level 95-100 - 70% success - God-tier items
```

---

## 🌲 RESOURCE GATHERING SYSTEMS

### 1. MINER PROFESSION

#### Mining (Ore Nodes)
**Purpose**: Primary metal source for weapons and armor

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T0 | Stone | 1 | 80-160 | 120 | 100% |
| T1 | Copper Ore | 1 | 50-100 | 300 | 100% |
| T2 | Iron Ore | 10 | 40-80 | 600 | 98% |
| T3 | Steel Ore | 20 | 30-60 | 900 | 95% |
| T4 | Mithril Ore | 35 | 20-40 | 1200 | 90% |
| T5 | Adamantine Ore | 50 | 15-30 | 1800 | 85% |
| T6 | Orichalcum Ore | 65 | 10-20 | 2400 | 80% |
| T7 | Starmetal Ore | 80 | 5-15 | 3600 | 75% |
| T8 | Divine Ore | 95 | 3-10 | 7200 | 70% |

**Bonus Drops (Rare Nodes):**
- Coal (T0-T2): 30% chance, 1-3 qty
- Sulfur (T1-T3): 15% chance, 1-2 qty
- Limestone (T2-T4): 10% chance, 1-2 qty

#### Gem Harvesting
**Purpose**: Socketing, enchanting, high-value trade

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T1 | Rough Gem | 5 | 10-20 | 600 | 100% |
| T2 | Flawed Gem | 15 | 8-16 | 900 | 98% |
| T3 | Standard Gem | 25 | 6-12 | 1200 | 95% |
| T4 | Fine Gem | 35 | 5-10 | 1800 | 90% |
| T5 | Pristine Gem | 50 | 4-8 | 2400 | 85% |
| T6 | Flawless Gem | 65 | 3-6 | 3600 | 80% |
| T7 | Radiant Gem | 80 | 2-4 | 5400 | 75% |
| T8 | Divine Gem | 95 | 1-3 | 10800 | 70% |

**Gem Types (Random on harvest):**
- Ruby (Fire damage)
- Sapphire (Ice damage)
- Emerald (Nature damage)
- Topaz (Lightning damage)
- Amethyst (Arcane damage)
- Diamond (Holy damage)

---

### 2. FORESTER PROFESSION

#### Woodcutting
**Purpose**: Bows, staves, arrows, furniture

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T0 | Stick | 1 | 100-200 | 60 | 100% |
| T1 | Pine Log | 1 | 60-120 | 240 | 100% |
| T2 | Oak Log | 10 | 50-100 | 480 | 98% |
| T3 | Maple Log | 20 | 40-80 | 720 | 95% |
| T4 | Ash Log | 35 | 30-60 | 960 | 90% |
| T5 | Ironwood Log | 50 | 20-40 | 1440 | 85% |
| T6 | Ebony Log | 65 | 15-30 | 1920 | 80% |
| T7 | Wyrmwood Log | 80 | 10-20 | 2880 | 75% |
| T8 | Worldtree Log | 95 | 5-15 | 5760 | 70% |

#### Skinning for Leather
**Purpose**: Leather armor, bowstrings, bags

| Tier | Material | Level | Beasts/Island | Respawn (sec) | Drop Rate |
|------|----------|-------|---------------|---------------|-----------|
| T0 | Scrap Leather | 1 | 60-120 | 120 | 100% |
| T1 | Rawhide | 1 | 30-60 | 360 | 90% |
| T2 | Thick Hide | 10 | 25-50 | 600 | 85% |
| T3 | Hardened Leather | 20 | 20-40 | 900 | 80% |
| T4 | Scaled Hide | 35 | 15-30 | 1200 | 75% |
| T5 | Dragon Scale | 50 | 12-24 | 1800 | 70% |
| T6 | Demon Hide | 65 | 8-16 | 2400 | 65% |
| T7 | Titan Leather | 80 | 5-10 | 3600 | 60% |
| T8 | Divine Leather | 95 | 3-6 | 7200 | 55% |

#### Skinning for Meat
**Purpose**: Chef ingredients, pet food, trade

| Tier | Material | Level | Beasts/Island | Respawn (sec) | Drop Rate |
|------|----------|-------|---------------|---------------|-----------|
| T0 | Raw Scraps | 1 | 60-120 | 120 | 100% |
| T1 | Raw Meat | 1 | 30-60 | 360 | 90% |
| T2 | Quality Meat | 10 | 25-50 | 600 | 85% |
| T3 | Prime Meat | 20 | 20-40 | 900 | 80% |
| T4 | Exotic Meat | 35 | 15-30 | 1200 | 75% |
| T5 | Dragon Meat | 50 | 12-24 | 1800 | 70% |
| T6 | Demon Meat | 65 | 8-16 | 2400 | 65% |
| T7 | Titan Meat | 80 | 5-10 | 3600 | 60% |
| T8 | Divine Meat | 95 | 3-6 | 7200 | 55% |

**Beast Types by Tier:**
- T0-T1: Hare, Sheep, Deer
- T2-T3: Wolf, Bear, Boar
- T4-T5: Wyvern, Chimera, Manticore
- T6-T7: Dragon, Demon, Titan
- T8: Divine Beasts

---

### 3. CHEF PROFESSION

#### Fishing
**Purpose**: Food, potions, alchemy ingredients

| Tier | Material | Level | Spots/Island | Respawn (sec) | Catch Rate |
|------|----------|-------|--------------|---------------|------------|
| T0 | Minnow | 1 | 70-140 | 90 | 100% |
| T1 | Common Fish | 1 | 50-100 | 180 | 95% |
| T2 | Salmon | 10 | 40-80 | 360 | 90% |
| T3 | Trout | 20 | 30-60 | 540 | 85% |
| T4 | Bass | 35 | 20-40 | 720 | 80% |
| T5 | Tuna | 50 | 15-30 | 1080 | 75% |
| T6 | Swordfish | 65 | 10-20 | 1440 | 70% |
| T7 | Kraken Tentacle | 80 | 5-10 | 2160 | 65% |
| T8 | Leviathan Scale | 95 | 3-6 | 4320 | 60% |

**Fishing Mechanics:**
- Requires fishing rod (craftable by Engineer)
- Bait increases catch rate by 10-25%
- Rare fish have special effects when cooked

#### Herbalist (Ingredients)
**Purpose**: Cooking, alchemy, potions

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T0 | Wild Herb | 1 | 80-160 | 90 | 100% |
| T1 | Common Herb | 1 | 50-100 | 240 | 100% |
| T2 | Quality Herb | 10 | 40-80 | 480 | 98% |
| T3 | Rare Herb | 20 | 30-60 | 720 | 95% |
| T4 | Exotic Herb | 35 | 20-40 | 960 | 90% |
| T5 | Mystic Herb | 50 | 15-30 | 1440 | 85% |
| T6 | Ancient Herb | 65 | 10-20 | 1920 | 80% |
| T7 | Celestial Herb | 80 | 5-10 | 2880 | 75% |
| T8 | Divine Herb | 95 | 3-6 | 5760 | 70% |

---

### 4. MYSTIC PROFESSION

#### Alchemy (Essence Gathering)
**Purpose**: Enchanting, magical crafting, infusions

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T1 | Minor Essence | 1 | 40-80 | 420 | 100% |
| T2 | Lesser Essence | 10 | 35-70 | 660 | 98% |
| T3 | Essence | 20 | 30-60 | 900 | 95% |
| T4 | Greater Essence | 35 | 25-50 | 1200 | 90% |
| T5 | Superior Essence | 50 | 20-40 | 1800 | 85% |
| T6 | Pristine Essence | 65 | 15-30 | 2400 | 80% |
| T7 | Radiant Essence | 80 | 10-20 | 3600 | 75% |
| T8 | Divine Essence | 95 | 5-10 | 7200 | 70% |

**Essence Types:**
- Arcane Essence (general magic)
- Void Essence (dark magic)
- Celestial Essence (holy magic)
- Primal Essence (nature magic)

#### Herbalist (Fiber/Cloth)
**Purpose**: Cloth armor, bandages, enchanted robes

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T0 | Plant Fiber | 1 | 80-160 | 90 | 100% |
| T1 | Linen Thread | 1 | 50-100 | 300 | 100% |
| T2 | Wool Thread | 10 | 40-80 | 600 | 98% |
| T3 | Cotton Thread | 20 | 30-60 | 900 | 95% |
| T4 | Silk Thread | 35 | 20-40 | 1200 | 90% |
| T5 | Moonweave Thread | 50 | 15-30 | 1800 | 85% |
| T6 | Starweave Thread | 65 | 10-20 | 2400 | 80% |
| T7 | Voidweave Thread | 80 | 5-10 | 3600 | 75% |
| T8 | Divine Thread | 95 | 3-6 | 7200 | 70% |

---

### 5. ENGINEER PROFESSION

#### Scrap Harvesting
**Purpose**: Mechanical components, guns, explosives

| Tier | Material | Level | Nodes/Island | Respawn (sec) | Success Rate |
|------|----------|-------|--------------|---------------|--------------|
| T0 | Metal Scrap | 1 | 100-200 | 120 | 100% |
| T1 | Copper Scrap | 1 | 60-120 | 300 | 100% |
| T2 | Iron Scrap | 10 | 50-100 | 600 | 98% |
| T3 | Steel Scrap | 20 | 40-80 | 900 | 95% |
| T4 | Mithril Scrap | 35 | 30-60 | 1200 | 90% |
| T5 | Adamantine Scrap | 50 | 20-40 | 1800 | 85% |
| T6 | Orichalcum Scrap | 65 | 15-30 | 2400 | 80% |
| T7 | Starmetal Scrap | 80 | 10-20 | 3600 | 75% |
| T8 | Divine Scrap | 95 | 5-10 | 7200 | 70% |

#### Recycling (Components)
**Purpose**: Gears, circuits, springs, lenses

| Tier | Material | Level | Sources | Yield | Success Rate |
|------|----------|-------|---------|-------|--------------|
| T1 | Broken Gear | 5 | Salvage | 1-3 | 90% |
| T2 | Damaged Circuit | 15 | Salvage | 1-2 | 85% |
| T3 | Worn Spring | 25 | Salvage | 1-2 | 80% |
| T4 | Cracked Lens | 35 | Salvage | 1 | 75% |
| T5 | Burnt Core | 50 | Salvage | 1 | 70% |
| T6 | Shattered Crystal | 65 | Salvage | 1 | 65% |
| T7 | Void Fragment | 80 | Salvage | 1 | 60% |
| T8 | Divine Fragment | 95 | Salvage | 1 | 55% |

**Recycling Sources:**
- Failed crafts (50% material return)
- Broken equipment (25% material return)
- Enemy mechanical drops (100% yield)

---

## 🗡️ MOB DROP TABLES

### Design Philosophy
- **Common mobs**: Basic materials, small gold
- **Uncommon mobs**: Better materials, recipes (rare)
- **Rare mobs**: High-tier materials, uncommon recipes
- **Elite mobs**: Guaranteed rare drops, epic recipes
- **Boss mobs**: Legendary items, unique recipes, infusions

### Drop Rate Formulas
```
Base Drop Rate = Item Rarity Chance
Level Bonus = (Player Level - Mob Level) * 0.5% (max +10%)
Profession Bonus = Profession Level / 10 * 1% (max +10%)
Final Drop Rate = min(Base * (1 + Level Bonus + Profession Bonus), 95%)
```

### Common Mobs (Level 1-100)
**Examples**: Skeleton, Goblin, Slime, Wolf, Bandit

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 80% | 5-15 | Scales with mob level |
| Tier Material | 40% | 1-3 | Matches mob tier |
| Consumable (Potion) | 15% | 1 | Health/Mana potion |
| Equipment (Common) | 5% | 1 | Same tier as mob |
| Recipe Fragment | 2% | 1 | Combine 5 for recipe |

**Level Scaling:**
- Level 1-10: T0-T1 materials, 5-15 gold
- Level 11-20: T2 materials, 15-30 gold
- Level 21-35: T3 materials, 30-60 gold
- Level 36-50: T4 materials, 60-120 gold
- Level 51-65: T5 materials, 120-250 gold
- Level 66-80: T6 materials, 250-500 gold
- Level 81-95: T7 materials, 500-1000 gold
- Level 96-100: T8 materials, 1000-2000 gold

---

### Uncommon Mobs (Elite Variants)
**Examples**: Elite Skeleton, Orc Warrior, Ice Elemental, Shadow Beast

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 25-75 | 3x common mob gold |
| Tier Material | 70% | 3-6 | Guaranteed better yield |
| Rare Material | 25% | 1-2 | One tier higher |
| Equipment (Uncommon) | 15% | 1 | Green quality |
| Recipe | 5% | 1 | Uncommon recipes |
| Infusion Essence (Minor) | 3% | 1 | T1-T2 infusions |

**Spawn Rate**: 15% of common mob spawns become uncommon

---

### Rare Mobs (Named Elites)
**Examples**: Bloodfang Alpha, Frost Giant, Void Stalker, Ancient Golem

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 100-300 | 10x common mob gold |
| Tier Material | 100% | 5-10 | Always drops |
| Rare Material | 60% | 2-4 | One tier higher |
| Equipment (Rare) | 35% | 1 | Blue quality |
| Recipe | 15% | 1 | Rare recipes |
| Infusion Essence (Lesser) | 10% | 1 | T2-T3 infusions |
| Unique Material | 5% | 1 | Special crafting component |

**Spawn Rate**: 3% of common mob spawns become rare
**Respawn Time**: 30-60 minutes

---

### Elite Mobs (Mini-Bosses)
**Examples**: Demon Commander, Dragon Whelp, Lich Apprentice, Titan Spawn

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 500-1500 | 50x common mob gold |
| Tier Material | 100% | 10-20 | Guaranteed large yield |
| Rare Material | 100% | 5-10 | Always drops |
| Epic Material | 40% | 1-3 | Two tiers higher |
| Equipment (Epic) | 50% | 1 | Purple quality |
| Recipe | 30% | 1 | Epic recipes |
| Infusion Essence (Greater) | 25% | 1-2 | T3-T4 infusions |
| Unique Material | 15% | 1-2 | Boss-specific components |

**Spawn Rate**: 1% of common mob spawns become elite
**Respawn Time**: 2-4 hours
**Announcement**: Server-wide notification on spawn

---

## 👑 BOSS LOOT SYSTEMS

### World Bosses (Open World)
**Examples**: Ancient Dragon, Demon Lord, Titan King, Void Leviathan

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 5000-15000 | Massive gold reward |
| Tier Material | 100% | 50-100 | Flood of materials |
| Epic Material | 100% | 10-20 | Guaranteed epics |
| Legendary Material | 60% | 3-5 | Boss-specific |
| Equipment (Legendary) | 40% | 1 | Orange quality, unique stats |
| Recipe (Legendary) | 25% | 1 | Exclusive boss recipes |
| Infusion Essence (Perfect) | 50% | 2-4 | T5 infusions |
| Profession Infusion | 20% | 1 | Profession-specific T3-T5 |
| Unique Cosmetic | 10% | 1 | Boss-themed appearance |
| Mount/Pet | 5% | 1 | Rare collectibles |

**Spawn Rate**: 1 per zone, 12-24 hour respawn
**Participation Rewards**: All players who damage boss get loot
**Top Contributor Bonus**: +50% drop rates for highest damage dealer

---

### Dungeon Bosses
**Examples**: Lich King, Abyss Demon Lord, Frost Wyrm, Shadow Archon

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 2000-6000 | Per party member |
| Tier Material | 100% | 20-40 | Dungeon tier materials |
| Epic Material | 80% | 5-10 | Dungeon-specific |
| Legendary Material | 30% | 1-3 | Rare boss drops |
| Equipment (Epic) | 60% | 1 | Dungeon set pieces |
| Equipment (Legendary) | 15% | 1 | Boss signature items |
| Recipe (Epic) | 40% | 1 | Dungeon recipes |
| Infusion Essence (Superior) | 40% | 1-2 | T4 infusions |
| Dungeon Token | 100% | 10-25 | Trade for rewards |

**Difficulty Scaling:**
- Normal: Base drop rates
- Hard: +25% drop rates, +1 tier materials
- Mythic: +50% drop rates, +2 tier materials, guaranteed legendary

---

### Raid Bosses (20-Player Content)
**Examples**: God Avatars, Primordial Titans, Void Lords, Celestial Dragons

**Drop Table Structure:**
| Item Type | Drop Chance | Quantity | Notes |
|-----------|-------------|----------|-------|
| Gold | 100% | 10000-30000 | Split among raid |
| Legendary Material | 100% | 20-40 | Guaranteed legendaries |
| Mythic Material | 50% | 5-10 | Raid-exclusive |
| Equipment (Legendary) | 80% | 2-4 | Raid set pieces |
| Equipment (Mythic) | 20% | 1 | Best-in-slot items |
| Recipe (Legendary) | 60% | 1-2 | Raid recipes |
| Infusion Essence (Perfect) | 100% | 5-10 | T5 infusions |
| Profession Infusion | 40% | 1-2 | T4-T5 profession-specific |
| Raid Token | 100% | 50-100 | Trade for tier sets |
| Unique Title | 10% | 1 | Prestigious titles |
| Legendary Mount | 2% | 1 | Ultra-rare mounts |

**Lockout**: Once per week per boss
**Loot Distribution**: Personal loot + bonus rolls

---

## 📅 DAILY MISSION REWARDS

### Daily Quest Tiers

#### Tier 1: Beginner Dailies (Level 1-20)
**Examples**: "Gather 20 Copper Ore", "Kill 10 Skeletons", "Craft 5 Copper Swords"

**Rewards:**
- XP: 500-1000
- Gold: 100-250
- Materials: 10-20 T1-T2 materials
- Reputation: +50 with quest faction
- Bonus: 5% chance for uncommon recipe

#### Tier 2: Intermediate Dailies (Level 21-50)
**Examples**: "Harvest 30 Rare Herbs", "Defeat Elite Orc", "Fish 15 Salmon"

**Rewards:**
- XP: 2000-4000
- Gold: 500-1000
- Materials: 15-30 T3-T4 materials
- Reputation: +100 with quest faction
- Infusion Essence: 1-2 Lesser Infusions
- Bonus: 10% chance for rare recipe

#### Tier 3: Advanced Dailies (Level 51-80)
**Examples**: "Mine 20 Adamantine Ore", "Kill 5 Elite Demons", "Craft Legendary Weapon"

**Rewards:**
- XP: 8000-15000
- Gold: 2000-4000
- Materials: 20-40 T5-T6 materials
- Reputation: +200 with quest faction
- Infusion Essence: 2-4 Greater Infusions
- Equipment: 1 Epic item (50% chance)
- Bonus: 20% chance for epic recipe

#### Tier 4: Master Dailies (Level 81-100)
**Examples**: "Gather 10 Divine Ore", "Defeat World Boss", "Complete Mythic Dungeon"

**Rewards:**
- XP: 25000-50000
- Gold: 8000-15000
- Materials: 30-60 T7-T8 materials
- Reputation: +500 with quest faction
- Infusion Essence: 5-10 Perfect Infusions
- Equipment: 1 Legendary item (75% chance)
- Recipe: 1 Legendary recipe (40% chance)
- Bonus: 5% chance for mythic item

---

### Weekly Quests
**Completion Bonus**: 5x daily quest rewards
**Special Rewards**:
- Guaranteed legendary item
- 10-20 Perfect Infusions
- 1 Profession-specific Infusion (T4-T5)
- 25000-50000 gold
- +1000 reputation with quest faction

---

## 💰 ECONOMY BALANCE

### Resource Flow Rates (Per Hour of Gathering)

| Profession | T1 Materials | T4 Materials | T8 Materials | Gold Value |
|------------|--------------|--------------|--------------|------------|
| Miner | 60-100 ore | 20-40 ore | 5-10 ore | 500-1000g |
| Forester | 80-120 logs | 25-45 logs | 6-12 logs | 400-800g |
| Chef | 100-150 fish/herbs | 30-50 fish/herbs | 8-15 fish/herbs | 300-600g |
| Mystic | 70-110 essence | 22-42 essence | 5-10 essence | 600-1200g |
| Engineer | 90-140 scrap | 28-48 scrap | 7-13 scrap | 450-900g |

### Crafting Material Costs (Market Value)

| Tier | Raw Material | Processed Material | Crafted Item | Profit Margin |
|------|--------------|-------------------|--------------|---------------|
| T1 | 5-10g | 15-25g | 50-100g | 30-50% |
| T2 | 15-25g | 40-60g | 150-250g | 35-45% |
| T3 | 40-70g | 100-150g | 400-700g | 40-50% |
| T4 | 100-180g | 250-400g | 1000-1800g | 45-55% |
| T5 | 250-450g | 600-1000g | 2500-4500g | 50-60% |
| T6 | 600-1100g | 1500-2500g | 6000-11000g | 55-65% |
| T7 | 1500-2800g | 3500-6000g | 15000-28000g | 60-70% |
| T8 | 4000-7500g | 9000-15000g | 40000-75000g | 65-75% |

### Gold Sinks (Prevent Inflation)
- Crafting station fees: 1-10% of item value
- Repair costs: 5-15% of item value
- Fast travel: 50-500g per zone
- Respec costs: 1000-10000g
- Mount training: 5000-50000g
- Guild creation: 10000g
- Auction house fees: 5% listing, 5% sale

---

## 🎓 PROFESSION BONUSES

### Gathering Speed Bonuses
```
Level 1-20:   Base speed (100%)
Level 21-40:  +10% speed
Level 41-60:  +25% speed
Level 61-80:  +40% speed
Level 81-100: +60% speed
```

### Yield Bonuses
```
Level 1-20:   Base yield (1x)
Level 21-40:  +10% yield (1.1x)
Level 41-60:  +25% yield (1.25x)
Level 61-80:  +50% yield (1.5x)
Level 81-100: +100% yield (2x)
```

### Rare Node Detection
```
Level 1-20:   No detection
Level 21-40:  Rare nodes glow (10m range)
Level 41-60:  Rare nodes glow (25m range)
Level 61-80:  Rare + Epic nodes glow (50m range)
Level 81-100: All special nodes glow (100m range)
```

### Critical Gathering
```
Level 1-20:   5% crit (2x yield)
Level 21-40:  10% crit (2x yield)
Level 41-60:  15% crit (2.5x yield)
Level 61-80:  20% crit (3x yield)
Level 81-100: 25% crit (4x yield)
```

---

## 📊 IMPLEMENTATION CHECKLIST

### Phase 1: Core Systems ✅
- [x] Define all gathering node types (10 methods)
- [x] Create tier progression (T0-T8)
- [x] Establish rarity system (Common to Legendary)
- [x] Design drop rate formulas

### Phase 2: Data Files (IN PROGRESS)
- [x] GATHERING_NODES.csv (130+ entries)
- [x] MASTER_MATERIALS.csv (186+ materials)
- [ ] MOB_DROP_TABLES.csv
- [ ] BOSS_LOOT_TABLES.csv
- [ ] DAILY_MISSION_REWARDS.csv
- [ ] INFUSION_MATERIALS.csv (20 infusions)

### Phase 3: Code Implementation
- [ ] Update server harvestingService.ts (add fish, meat, scrap nodes)
- [ ] Add T0 nodes to server
- [ ] Implement mob drop system
- [ ] Create boss loot generator
- [ ] Build daily mission reward system

### Phase 4: Balance Testing
- [ ] Test gathering rates per hour
- [ ] Verify economy balance
- [ ] Adjust drop rates based on playtesting
- [ ] Fine-tune profession bonuses

---

**END OF GAME MASTER DESIGN DOCUMENT**

