const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

console.log('Starting UUID test...');

const filePath = path.join(__dirname, 'MASTER_MATERIALS.csv');
console.log('File path:', filePath);
console.log('File exists:', fs.existsSync(filePath));

if (fs.existsSync(filePath)) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');
  console.log('Total lines:', lines.length);
  console.log('First 5 lines:');
  lines.slice(0, 5).forEach((line, i) => {
    console.log(`  ${i}: ${line.substring(0, 80)}`);
  });
}

console.log('Test complete!');

