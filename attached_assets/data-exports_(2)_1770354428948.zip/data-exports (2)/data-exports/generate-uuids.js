/**
 * GRUDGE UUID Generator for Data Exports
 * Generates and assigns UUIDs to all CSV files following GRUDGE UUID format
 * Format: PREFIX-TIMESTAMP-SEQUENCE-HASH
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// UUID Prefix mapping
const PREFIX_MAP = {
  material: 'MATL',
  recipe: 'RECP',
  node: 'NODE',
  mob: 'MOBS',
  boss: 'BOSS',
  mission: 'MISS',
  infusion: 'INFU',
};

// Counter for sequence generation
let sequenceCounter = 0;

/**
 * Generate a GRUDGE UUID
 * @param {string} prefix - Entity type prefix
 * @param {object} metadata - Entity metadata for hash generation
 * @returns {string} GRUDGE UUID in format PREFIX-TIMESTAMP-SEQUENCE-HASH
 */
function generateGrudgeUuid(prefix, metadata = {}) {
  // Timestamp in YYYYMMDDHHMMSS format
  const now = new Date();
  const timestamp = now.toISOString()
    .replace(/[-:T.Z]/g, '')
    .substring(0, 14);
  
  // Sequence number (6 hex digits)
  sequenceCounter++;
  const sequence = sequenceCounter.toString(16).padStart(6, '0').toUpperCase();
  
  // Hash of metadata (8 hex digits)
  const metadataString = JSON.stringify(metadata);
  const hash = crypto
    .createHash('sha256')
    .update(metadataString + now.getTime() + sequenceCounter)
    .digest('hex')
    .substring(0, 8)
    .toUpperCase();
  
  return `${prefix}-${timestamp}-${sequence}-${hash}`;
}

/**
 * Parse CSV file
 * @param {string} filePath - Path to CSV file
 * @returns {Object} Object with headers and rows
 */
function parseCSV(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n')
    .map(line => line.trim())
    .filter(line => line && !line.startsWith('#'));

  if (lines.length === 0) {
    return { headers: [], rows: [] };
  }

  const headers = lines[0].split(',').map(h => h.trim());
  const rows = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line) continue;

    const values = line.split(',').map(v => v.trim());
    const row = {};
    headers.forEach((header, index) => {
      row[header] = values[index] || '';
    });
    rows.push(row);
  }

  return { headers, rows };
}

/**
 * Write CSV file with UUIDs
 * @param {string} filePath - Path to output CSV file
 * @param {Array} headers - CSV headers
 * @param {Array} rows - CSV rows
 */
function writeCSV(filePath, headers, rows) {
  const lines = [headers.join(',')];
  
  rows.forEach(row => {
    const values = headers.map(header => row[header] || '');
    lines.push(values.join(','));
  });
  
  fs.writeFileSync(filePath, lines.join('\n'), 'utf-8');
  console.log(`✅ Written: ${filePath}`);
}

/**
 * Add UUIDs to MASTER_MATERIALS.csv
 */
function addUuidsToMaterials() {
  console.log('\n📦 Processing MASTER_MATERIALS.csv...');

  const filePath = path.join(__dirname, 'MASTER_MATERIALS.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);
  console.log(`   Found ${rows.length} materials`);

  // Add GrudgeUUID column if not exists
  if (!headers.includes('GrudgeUUID')) {
    headers.splice(1, 0, 'GrudgeUUID'); // Insert after MaterialID
  }

  let generated = 0;
  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.material, {
        entityType: 'material',
        entityId: row.MaterialID,
        entityName: row.Name,
        tier: parseInt(row.Tier) || 0,
        category: row.Category,
      });
      generated++;
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   ✅ Generated ${generated} new UUIDs`);
}

/**
 * Add UUIDs to recipe files
 * @param {string} profession - Profession name
 */
function addUuidsToRecipes(profession) {
  console.log(`\n⚒️  Processing COMPLETE_${profession.toUpperCase()}_RECIPES.csv...`);
  
  const filePath = path.join(__dirname, `COMPLETE_${profession.toUpperCase()}_RECIPES.csv`);
  
  if (!fs.existsSync(filePath)) {
    console.log(`   ⚠️  File not found, skipping...`);
    return;
  }
  
  const { headers, rows } = parseCSV(filePath);
  
  // Add GrudgeUUID column if not exists
  if (!headers.includes('GrudgeUUID')) {
    headers.splice(1, 0, 'GrudgeUUID'); // Insert after RecipeID
  }
  
  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.recipe, {
        entityType: 'recipe',
        entityId: row.RecipeID,
        entityName: row.RecipeName,
        tier: parseInt(row.Tier) || 0,
        profession: profession,
        category: row.Category,
      });
    }
  });
  
  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} recipe UUIDs`);
}

/**
 * Add UUIDs to gathering nodes
 */
function addUuidsToGatheringNodes() {
  console.log('\n🌲 Processing GATHERING_NODES.csv...');

  const filePath = path.join(__dirname, 'GATHERING_NODES.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);

  if (!headers.includes('GrudgeUUID')) {
    headers.splice(1, 0, 'GrudgeUUID');
  }

  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.node, {
        entityType: 'node',
        entityId: row.NodeType,
        entityName: row.NodeType,
        tier: parseInt(row.Tier) || 0,
        method: row.GatheringMethod,
        profession: row.Profession,
      });
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} node UUIDs`);
}

/**
 * Add UUIDs to mob drop tables
 */
function addUuidsToMobDrops() {
  console.log('\n👹 Processing MOB_DROP_TABLES.csv...');

  const filePath = path.join(__dirname, 'MOB_DROP_TABLES.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);

  if (!headers.includes('GrudgeUUID')) {
    headers.splice(0, 0, 'GrudgeUUID');
  }

  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.mob, {
        entityType: 'mob_drop',
        rarity: row.MobRarity,
        levelRange: row.LevelRange,
      });
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} mob drop UUIDs`);
}

/**
 * Add UUIDs to boss loot tables
 */
function addUuidsToBossLoot() {
  console.log('\n👑 Processing BOSS_LOOT_TABLES.csv...');

  const filePath = path.join(__dirname, 'BOSS_LOOT_TABLES.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);

  if (!headers.includes('GrudgeUUID')) {
    headers.splice(0, 0, 'GrudgeUUID');
  }

  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.boss, {
        entityType: 'boss_loot',
        bossType: row.BossType,
        bossName: row.BossName,
        level: parseInt(row.Level) || 0,
      });
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} boss loot UUIDs`);
}

/**
 * Add UUIDs to daily missions
 */
function addUuidsToMissions() {
  console.log('\n📅 Processing DAILY_MISSION_REWARDS.csv...');

  const filePath = path.join(__dirname, 'DAILY_MISSION_REWARDS.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);

  if (!headers.includes('GrudgeUUID')) {
    headers.splice(0, 0, 'GrudgeUUID');
  }

  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.mission, {
        entityType: 'mission',
        missionType: row.MissionType,
        tier: row.Tier,
        frequency: row.Frequency,
      });
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} mission UUIDs`);
}

/**
 * Add UUIDs to infusion materials
 */
function addUuidsToInfusions() {
  console.log('\n✨ Processing INFUSION_MATERIALS.csv...');

  const filePath = path.join(__dirname, 'INFUSION_MATERIALS.csv');

  if (!fs.existsSync(filePath)) {
    console.log('   ⚠️  File not found, skipping...');
    return;
  }

  const { headers, rows } = parseCSV(filePath);

  if (!headers.includes('GrudgeUUID')) {
    headers.splice(1, 0, 'GrudgeUUID');
  }

  rows.forEach(row => {
    if (!row.GrudgeUUID) {
      row.GrudgeUUID = generateGrudgeUuid(PREFIX_MAP.infusion, {
        entityType: 'infusion',
        entityId: row.InfusionID,
        entityName: row.Name,
        tier: parseInt(row.Tier) || 0,
        type: row.Type,
      });
    }
  });

  writeCSV(filePath, headers, rows);
  console.log(`   Generated ${rows.length} infusion UUIDs`);
}

// Main execution
console.log('🎮 GRUDGE UUID Generator for Data Exports');
console.log('==========================================\n');

try {
  // Generate UUIDs for materials
  addUuidsToMaterials();

  // Generate UUIDs for all profession recipes
  ['miner', 'forester', 'chef', 'mystic', 'engineer'].forEach(profession => {
    addUuidsToRecipes(profession);
  });

  // Generate UUIDs for gathering nodes
  addUuidsToGatheringNodes();

  // Generate UUIDs for loot/reward tables
  addUuidsToMobDrops();
  addUuidsToBossLoot();
  addUuidsToMissions();
  addUuidsToInfusions();

  console.log('\n✅ UUID generation complete!');
  console.log(`📊 Total UUIDs generated: ${sequenceCounter}`);
  console.log('\n📋 Files updated:');
  console.log('   - MASTER_MATERIALS.csv');
  console.log('   - COMPLETE_MINER_RECIPES.csv');
  console.log('   - COMPLETE_FORESTER_RECIPES.csv');
  console.log('   - COMPLETE_CHEF_RECIPES.csv');
  console.log('   - GATHERING_NODES.csv');
  console.log('   - MOB_DROP_TABLES.csv');
  console.log('   - BOSS_LOOT_TABLES.csv');
  console.log('   - DAILY_MISSION_REWARDS.csv');
  console.log('   - INFUSION_MATERIALS.csv');

} catch (error) {
  console.error('\n❌ Error:', error.message);
  console.error(error.stack);
  process.exit(1);
}

