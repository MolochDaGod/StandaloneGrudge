# Server Configuration Guide

## ⚠️ SECURITY WARNING
**This file contains sensitive credentials. DO NOT commit to public repositories!**

---

## Database Configuration

### Production MySQL Database

```yaml
Host: 74.208.155.229
Port: 3306
Database: grudge_game
Username: grudge_admin
Password: Grudge2026!
```

### Connection String

```bash
# MySQL Connection String
mysql://grudge_admin:Grudge2026!@74.208.155.229:3306/grudge_game

# For Node.js (DATABASE_URL)
DATABASE_URL="mysql://grudge_admin:Grudge2026!@74.208.155.229:3306/grudge_game"
```

---

## Game Server Configuration

### Character Manager Server

```yaml
IP: 74.208.174.62
Port: 7777
Purpose: Character management and authentication
```

### Scene Servers

#### Brocelie Scene
```yaml
Scene Name: Brocelie
IP: 74.208.174.62
Port: 7778
Purpose: Brocelie forest zone
```

#### Game Scene
```yaml
Scene Name: Game
IP: 74.208.174.62
Port: 7779
Purpose: Main game world
```

---

## uMMORPG Configuration

### NetworkManager Settings

```yaml
CharacterManager:
  ipServer: 74.208.174.62
  portServer: 7777

serverScenes:
  - sceneName: Brocelie
    ipServer: 74.208.174.62
    portServer: 7778
  - sceneName: Game
    ipServer: 74.208.174.62
    portServer: 7779
```

---

## Environment Variables

### Backend (.env)

```bash
# Database
DATABASE_URL="mysql://grudge_admin:Grudge2026!@74.208.155.229:3306/grudge_game"
DB_HOST=74.208.155.229
DB_PORT=3306
DB_NAME=grudge_game
DB_USER=grudge_admin
DB_PASSWORD=Grudge2026!

# Game Servers
CHARACTER_SERVER_IP=74.208.174.62
CHARACTER_SERVER_PORT=7777
BROCELIE_SERVER_IP=74.208.174.62
BROCELIE_SERVER_PORT=7778
GAME_SERVER_IP=74.208.174.62
GAME_SERVER_PORT=7779

# Session
SESSION_SECRET=your-session-secret-here

# API Keys (if needed)
PUTER_AUTH_TOKEN=your-puter-token
OPENAI_API_KEY=your-openai-key
```

### Frontend (.env.local)

```bash
# API Endpoints
VITE_BACKEND_URL=http://74.208.174.62:3000
VITE_WORKER_URL=https://your-puter-worker.puter.site

# Game Servers
VITE_CHARACTER_SERVER=74.208.174.62:7777
VITE_BROCELIE_SERVER=74.208.174.62:7778
VITE_GAME_SERVER=74.208.174.62:7779
```

---

## Database Access

### Using MySQL Client

```bash
# Connect to database
mysql -h 74.208.155.229 -P 3306 -u grudge_admin -p grudge_game

# Enter password when prompted: Grudge2026!
```

### Using MySQL Workbench

1. Create new connection
2. Connection Name: `Grudge Game Production`
3. Hostname: `74.208.155.229`
4. Port: `3306`
5. Username: `grudge_admin`
6. Password: `Grudge2026!`
7. Default Schema: `grudge_game`

---

## Firewall Rules

### Required Ports

| Port | Service | Access |
|------|---------|--------|
| 3306 | MySQL Database | Backend only |
| 7777 | Character Manager | Public (game clients) |
| 7778 | Brocelie Scene | Public (game clients) |
| 7779 | Game Scene | Public (game clients) |
| 3000 | Express Backend | Public (API) |

### Security Recommendations

1. **Database Access**:
   - Restrict MySQL port 3306 to backend server IP only
   - Use SSL/TLS for database connections
   - Rotate password regularly

2. **Game Servers**:
   - Use DDoS protection for game server ports
   - Implement rate limiting
   - Monitor for suspicious connections

3. **API Security**:
   - Use HTTPS for all API endpoints
   - Implement JWT authentication
   - Add CORS restrictions

---

## Testing Connections

### Test Database Connection

```bash
# Using Node.js
node -e "const mysql = require('mysql2'); const conn = mysql.createConnection('mysql://grudge_admin:Grudge2026!@74.208.155.229:3306/grudge_game'); conn.connect(err => { if(err) console.error(err); else console.log('Connected!'); conn.end(); });"
```

### Test Game Server Ports

```bash
# Test Character Manager
nc -zv 74.208.174.62 7777

# Test Brocelie Scene
nc -zv 74.208.174.62 7778

# Test Game Scene
nc -zv 74.208.174.62 7779
```

---

## Backup Configuration

### Database Backups

```bash
# Create backup
mysqldump -h 74.208.155.229 -P 3306 -u grudge_admin -p grudge_game > backup_$(date +%Y%m%d).sql

# Restore backup
mysql -h 74.208.155.229 -P 3306 -u grudge_admin -p grudge_game < backup_20260125.sql
```

---

## Troubleshooting

### Cannot Connect to Database

1. Check firewall allows port 3306
2. Verify credentials are correct
3. Ensure MySQL service is running
4. Check if IP is whitelisted

### Cannot Connect to Game Servers

1. Verify game server is running
2. Check firewall rules for ports 7777-7779
3. Test with telnet/nc
4. Check server logs

---

**Last Updated**: 2026-01-25  
**Environment**: Production  
**Status**: Active

