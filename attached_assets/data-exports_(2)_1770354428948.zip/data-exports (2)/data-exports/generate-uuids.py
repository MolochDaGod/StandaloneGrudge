#!/usr/bin/env python3
"""
GRUDGE UUID Generator for Data Exports
Generates and assigns UUIDs to all CSV files following GRUDGE UUID format
Format: PREFIX-TIMESTAMP-SEQUENCE-HASH
"""

import csv
import hashlib
import os
from datetime import datetime

# UUID Prefix mapping
PREFIX_MAP = {
    'material': 'MATL',
    'recipe': 'RECP',
    'node': 'NODE',
    'mob': 'MOBS',
    'boss': 'BOSS',
    'mission': 'MISS',
    'infusion': 'INFU',
}

# Counter for sequence generation
sequence_counter = 0

def generate_grudge_uuid(prefix, metadata=None):
    """Generate a GRUDGE UUID"""
    global sequence_counter
    
    if metadata is None:
        metadata = {}
    
    # Timestamp in YYYYMMDDHHMMSS format
    now = datetime.now()
    timestamp = now.strftime('%Y%m%d%H%M%S')
    
    # Sequence number (6 hex digits)
    sequence_counter += 1
    sequence = f"{sequence_counter:06X}"
    
    # Hash of metadata (8 hex digits)
    metadata_str = str(metadata) + str(now.timestamp()) + str(sequence_counter)
    hash_obj = hashlib.sha256(metadata_str.encode())
    hash_val = hash_obj.hexdigest()[:8].upper()
    
    return f"{prefix}-{timestamp}-{sequence}-{hash_val}"

def add_uuids_to_csv(filepath, prefix, id_column, uuid_insert_pos=1):
    """Add UUIDs to a CSV file"""
    if not os.path.exists(filepath):
        print(f"   ⚠️  File not found: {filepath}")
        return 0

    rows = []
    headers = None
    comment_lines = []

    # Read CSV and preserve comments
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            stripped = line.strip()

            # Preserve comment lines
            if stripped.startswith('#'):
                comment_lines.append(line.rstrip())
                continue

            # Skip empty lines
            if not stripped:
                continue

            # First non-comment line is headers
            if headers is None:
                headers = [h.strip() for h in stripped.split(',')]
                continue

            # Data rows
            values = [v.strip() for v in stripped.split(',')]
            # Pad values to match header length
            while len(values) < len(headers):
                values.append('')
            row_dict = dict(zip(headers, values))
            rows.append(row_dict)

    if not headers or not rows:
        print(f"   ⚠️  No data found in {filepath}")
        return 0

    # Add GrudgeUUID column if not exists
    if 'GrudgeUUID' not in headers:
        headers.insert(uuid_insert_pos, 'GrudgeUUID')

    # Generate UUIDs
    generated = 0
    for row in rows:
        if 'GrudgeUUID' not in row or not row.get('GrudgeUUID'):
            metadata = {
                'entityId': row.get(id_column, ''),
                'entityName': row.get('Name', row.get('RecipeName', '')),
            }
            row['GrudgeUUID'] = generate_grudge_uuid(prefix, metadata)
            generated += 1

    # Write CSV with comments preserved
    with open(filepath, 'w', encoding='utf-8', newline='') as f:
        # Write header
        f.write(','.join(headers) + '\n')

        # Write comment lines if any
        if comment_lines:
            for comment in comment_lines:
                f.write(comment + '\n')
            f.write('\n')  # Blank line after comments

        # Write data rows
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writerows(rows)

    print(f"   ✅ Generated {generated} new UUIDs for {len(rows)} rows")
    return generated

# Main execution
print('🎮 GRUDGE UUID Generator for Data Exports')
print('==========================================\n')

script_dir = os.path.dirname(os.path.abspath(__file__))
total_generated = 0

# Materials
print('📦 Processing MASTER_MATERIALS.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'MASTER_MATERIALS.csv'),
    PREFIX_MAP['material'],
    'MaterialID',
    1
)

# Recipes
for profession in ['MINER', 'FORESTER', 'CHEF', 'MYSTIC', 'ENGINEER']:
    print(f'\n⚒️  Processing COMPLETE_{profession}_RECIPES.csv...')
    total_generated += add_uuids_to_csv(
        os.path.join(script_dir, f'COMPLETE_{profession}_RECIPES.csv'),
        PREFIX_MAP['recipe'],
        'RecipeID',
        1
    )

# Gathering Nodes
print('\n🌲 Processing GATHERING_NODES.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'GATHERING_NODES.csv'),
    PREFIX_MAP['node'],
    'NodeType',
    1
)

# Mob Drops
print('\n👹 Processing MOB_DROP_TABLES.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'MOB_DROP_TABLES.csv'),
    PREFIX_MAP['mob'],
    'MobRarity',
    0
)

# Boss Loot
print('\n👑 Processing BOSS_LOOT_TABLES.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'BOSS_LOOT_TABLES.csv'),
    PREFIX_MAP['boss'],
    'BossType',
    0
)

# Missions
print('\n📅 Processing DAILY_MISSION_REWARDS.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'DAILY_MISSION_REWARDS.csv'),
    PREFIX_MAP['mission'],
    'MissionType',
    0
)

# Infusions
print('\n✨ Processing INFUSION_MATERIALS.csv...')
total_generated += add_uuids_to_csv(
    os.path.join(script_dir, 'INFUSION_MATERIALS.csv'),
    PREFIX_MAP['infusion'],
    'InfusionID',
    1
)

# Gathering Profession Files
for profession in ['MINER', 'FORESTER', 'CHEF', 'MYSTIC', 'ENGINEER']:
    print(f'\n⛏️  Processing GATHERING_{profession}.csv...')
    total_generated += add_uuids_to_csv(
        os.path.join(script_dir, f'GATHERING_{profession}.csv'),
        'GATH',
        'GatheringMethod',
        0  # Insert at position 0 (first column)
    )

print(f'\n✅ UUID generation complete!')
print(f'📊 Total UUIDs generated: {total_generated}')

